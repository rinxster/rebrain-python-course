from task09 import *
print(dict1)